---
name: CD2
tools: [アルバム]
image: https://marketplace.canva.com/EADapDdJvvc/1/0/400w/canva-floral-illustration-cd-cover-%28album-cover%29--UUJe6HP5xo.jpg
description: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
external_url: https://www.google.com
---
